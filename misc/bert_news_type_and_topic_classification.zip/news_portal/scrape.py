import requests
import datetime
import time
import re
from bs4 import BeautifulSoup
class Scrape():
    def __init__(self):
        # print(f"news portals: {self.news_portals}")
        self.scrape_functions = {
            "detiknewsjabar" : self.__detik,
            "antaranewsjabar" : self.__jabarantaranews,
            "prbandung" : self.__prbandung,
        }
        self.articles = []
        pass    
    
    def scrape_news(self, news_portals: list, start_date: str, end_date: str):
        """
        Return news that's scraped from selected portal with specificied time
        
        Parameters
        ------------
        news_portals:
                    Available news portals: 
                    Detik News Jabar\t: detiknewsjabar
                    Antara News Jabar\t: antaranewsjabar
                    Pikiran Rakyat Bandung\t: prbandung
                    Sekitar Bandung\t: sekitarbandung
                    Tribun Jabar\t: tribunjabar
        start_date:
                    input start date with format: "yyyy-mm-dd"
                    example: 2023-08-23
        end_date:
                    input end date with format-> yyyy-mm-dd
                    example: 2023-10-1
        Returns
        ------------
        articles:
                 contains list of dictionaries that's store the id of news and news itself
                 example return: [
                     {
                         id  : "detik.com/news-1"
                         news: "some news text"
                     },
                     {
                         id  : "detik.com/news-2"
                         news: "some news text"
                     },
                ]
        """
        self.news_portals = news_portals
        self.start_date = start_date
        self.end_date = end_date
        print(f"hello world from scrape news")
        print(f"news portals {self.news_portals }")
        print(f"start date {self.start_date}")
        print(f"end date {self.end_date}")
        for portal in self.news_portals:
            print('print portal from for iteration')
            self.scrape_functions[portal]()
        return self.articles
        # pass
    def get_scraped_news(self):
        """
        Returns
        ------------
        articles:
                list of dictionaries that contain news id and scraped news 
        """
        return self.articles
    # def convert_mon(self, month, portal_id):
    def convert_mon(self, month):
        # print(f"old month: {month}")
        months = {
            "01" : ["Jan", "January", "Januari"],
            "02" : ["Feb", "February", "Februari"],
            "03" : ["Mar", "March", "Maret"],
            "04" : ["Apr", "April"],
            "05" : ["May", "Mei"],
            "06" : ["Jun", "June", "Juni"],
            "07" : ["Jul", "July", "Juli"],
            "08" : ["Aug", "Agu", "August","Agustus"],
            "09" : ["Sep", "September"],
            "10" : ["Oct"," Okt", "October","Oktober"],
            "11" : ["Nov"," November","Nopember"],
            "12" : ["Dec"," Des", "December","Desember"],
        }
        for key, value in months.items():
            if type(month) is not str:
                if month.group(1) in value:
                    month = key
                    break
            else:
                if month in value:
                    month = key
                    break
                
                
        # print(f"new month: {month}")
        return month
    def get_news_date(self, raw_date):
        """
        Return new news date format that will be converted from news date 
        
        Parameters
        ------------
        raw_date :
                    date that will be converted from format that's 
                    come from each news portal to a new date format.
                    Example:
                    original format: 12 March 2021
                    new format: 2021-03-12
                    or
                    original format: blablabla 12 March 2021 blablabla
                    new format: 2021-03-12
        Returns
        ------------
        news_date:
                    new news date format
        """
        news_date = re.search("([0-9]+\s[A-Za-z]+\s[0-9]+)", raw_date).group(1)
        # print(f"news date from get news date: {news_date}")
        news_date = re.sub(r"([A-Za-z]+)",  self.convert_mon, news_date)
        news_date = news_date.split(" ")
        news_date.reverse()
        news_date = "-".join(news_date)
        # print("news_date: {}".format(news_date))
        return news_date
    def __detik(self):
        loopable = True
        page = 1
        while loopable:
            # print(f"page {page}")
            url = f"https://www.detik.com/tag/jawa-barat/?sortby=time&page={page}"
            request = requests.get(url)
            articles_page = BeautifulSoup(request.content,"html5lib")
            # print(type(articles_page))
            for i, article in enumerate(articles_page.find_all("article")):
                get_date = article.find("span",{"class":{"date"}})
                news_date = self.get_news_date(get_date.contents[1])
                # date_now = datetime.datetime.today().strftime('%Y-%m-%d')
                if news_date > self.end_date:
                    print("News date bigger than end date, skipped.")
                    continue
                if news_date >= self.start_date and news_date <= self.end_date:
                    print(f"article {i+1}")
                    news_link = article.find("a")
                    get_news = requests.get(news_link['href'])
                    print(f"news link: {news_link['href']}")
                    # news_id = re.search("https?://www.([\w\-]+(\.[\w\-]+)+\S*)", news_link['href']).group(1)
                    find_id = re.search("https?://www.([\w\-]+(\.[\w\-]+)+\S*)", news_link['href'])
                    if find_id:
                        news_id = find_id.group(1)
                    else:
                        news_id = news_link['href']
                    news_html = BeautifulSoup(get_news.content,"html5lib")
                    if news_html.find("div", {"class": {"paradetail"}}) is not None:
                        pass
                        news_html.find("div", {"class": {"paradetail"}}).decompose()
                        text = news_html.find("div",{"class":{"detail__body-text"}})
                        full_text = ""
                        for p in text.find_all("p"):
                            # print(p.text.strip())
                            full_text += p.text.strip()
                        self.articles.append({
                            "id": news_id,
                            "news": full_text
                        })
                else:
                    loopable = False
                    break
            page +=1
        # return self.articles
    def __jabarantaranews(self):
        loopable = True
        page = 1
        while loopable:
            print(f"page {page}")
            url = f"https://jabar.antaranews.com/terkini/{page}"
            request = requests.get(url)
            articles_page = BeautifulSoup(request.content,"html5lib")
            article_block = articles_page.find("div",{"class":{"col-md-8"}})
            for i, article in enumerate(article_block.find_all("article")):
                get_date = article.find("p",{"class":{"simple-share"}})                
                news_date = re.search("(jam\slalu|menit\slalu|detik\slalu)",get_date.text)
                if news_date:
                    print("news date equals today")
                    news_date = datetime.datetime.today().strftime('%Y-%m-%d')
                else:
                    print("news is not today")
                    
                    news_date = self.get_news_date(get_date.text)
                print(f"news date: {news_date}")
                if news_date > self.end_date:
                    print("News date bigger than end date, skipped.")
                    continue
                if news_date >= self.start_date and news_date <= self.end_date:
                    print(f"article {i+1}")
                    news_link = article.find("a")
                    get_news = requests.get(f"{news_link['href']}?page=all")
                    print(f"news link: {news_link['href']}")
                    news_id = re.search("https?://[A-Za-z0-9]+.([\w\-]+(\.[\w\-]+)+\S*)", news_link['href']).group(1)
                    news_html = BeautifulSoup(get_news.content,"html5lib")
                    text = news_html.find("div", {"class": {"post-content"}})
                    self.articles.append({
                        "id": news_id,
                        "news": text
                    })
                else:
                    loopable =False
                    break
                if page >100:
                    loopable = False
                    break
            page +=1
    def __prbandung(self):
        loopable = True
        page = 1
        while loopable:
            print(f"page {page}")
            url = f"https://www.pikiran-rakyat.com/bandung-raya?page={page}"
            request = requests.get(url)
            articles_page = BeautifulSoup(request.content,"html5lib")
            # article_block = articles_page.find("div",{"class":{"col-md-8"}})
            for i, article in enumerate(articles_page.find_all('div', {'class': {'latest__item'}})):
                print(f"article {i+1}")
                get_date = article.find("date")
                news_date = re.search("(jam\slalu|menit\slalu|detik\slalu)",get_date.text)
                # if news_date:
                #     print("news date equals today")
                #     news_date = datetime.datetime.today().strftime('%Y-%m-%d')
                # else:
                news_date = self.get_news_date(get_date.text)
                print(f"new news date: {news_date}")
                if news_date > self.end_date:
                    print("News date bigger than end date, skipped.")
                    continue
                if news_date >= self.start_date and news_date <= self.end_date:
                    news_link = article.find("a")
                    get_news = requests.get(f"{news_link['href']}?page=all")
                    print(f"news link: {news_link['href']}")
                    news_id = re.search("https?://[A-Za-z0-9]+.([\w\-]+(\.[\w\-]+)+\S*)", news_link['href']).group(1)
                    news_html = BeautifulSoup(get_news.content,"html5lib")
                    text = news_html.find("article", {"class": {"read__content"}})
                    print("text: ")
                    print(text.text)
                    time.sleep(3)
                    self.articles.append({
                        "id": news_id,
                        "news": text
                    })
                else:
                    loopable =False
                    break
                if page >10:
                    loopable = False
                    break
            page +=1
s = Scrape()
s.scrape_news(['prbandung'],"2023-03-17","2023-03-17")
articles = s.get_scraped_news()
print(f"article length:\n {len(articles)}")
# s.detik()