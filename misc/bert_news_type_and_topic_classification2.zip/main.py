from fastapi import FastAPI, Body, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.exceptions import HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import pipeline
from news_portal.scrape import Scrape

clf = pipeline(model="dimassamid/IndobertNewsTest")
type_clf = pipeline(model="rizalmilyardi/IndobertTypeNews")
origins = ["*"]

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/js", StaticFiles(directory="templates/js"), name="js")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
# scrape = Scrape(["detik","antaranews"])
templates = Jinja2Templates(directory="templates")
news_portals = [
    {"id": "detiknewsjabar","name": "Detik News Jabar"},
    {"id": "antaranewsjabar","name": "Antara News Jabar"},
    {"id": "tribunjabar","name": "Tribun Jabar"},
    {"id": "sekitarbandung","name": "Sekitar Bandung"},
    {"id": "prbandung","name": "Pikiran Rakyat Bandung"},
]
total_rows = 0
if len(news_portals)%3 ==0:
    total_rows = int(len(news_portals) / 3)
else:
    total_rows = int(len(news_portals) / 3) +1
# print(len(news_portals))

class News(BaseModel):
    news: str

class ScrapeInfo(BaseModel):
    portal: list
    start_date: str
    end_date: str
@app.get("/")
def redirect_from_slash():
    return RedirectResponse("http://127.0.0.1:8000/scrape")
@app.get("/classify", response_class=HTMLResponse)
def classify_news_ui(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
@app.get("/scrape",response_class=HTMLResponse)
def scrape_news(request: Request):
    return templates.TemplateResponse("scrape.html", {"request":request})
@app.get("/choose-portal",response_class=HTMLResponse)
def scrape_news(request: Request):
    id = "hello world is an id"
    print("hello world form choose-portal get")
    return templates.TemplateResponse("choose_portal.html", {"request":request, "news_portal": news_portals, "id": id})
@app.post("/choose-portal")
def scrape_news(scrape_info: ScrapeInfo, request: Request):
    scrape = Scrape(scrape_info.portal, scrape_info.start_date, scrape_info.end_date)
    scraped_news = scrape.scrape_news()
    print(scraped_news)
    print(f"type of portal: {type(scrape_info.portal)}")
    print(f"type of start_date: {type(scrape_info.start_date)}")
    print(f"type of end_date: {type(scrape_info.end_date)}")
    # return {
    #     "status" : "200",
    #     "message" : "success"
    # }
@app.post("/klasifikasi")
def classify_news(news_: News, request: Request):    
    news = r"{}".format(news_.news)
    print(f"request method: {request.method}")
    news_type = type_clf(news)[0]['label']
    
    if news_type == "non-kejadian":
        return {
            "message" : "success",
            "news_type" : news_type,
            "news_topic" : "-"
        }
    news_topic =clf(news)[0]['label']
    score = clf(news_.news)[0]['score']
    return {
        "message" : "success",
        "news_type" : news_type,
        "news_topic" : news_topic
    }
    
# @app.exception_handlers(404)
